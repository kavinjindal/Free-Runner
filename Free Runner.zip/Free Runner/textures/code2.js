gdjs.GAMECode = {};
gdjs.GAMECode.GDfinalbkObjects1= [];
gdjs.GAMECode.GDfinalbkObjects2= [];
gdjs.GAMECode.GDPlayerObjects1= [];
gdjs.GAMECode.GDPlayerObjects2= [];
gdjs.GAMECode.GDBaseObjects1= [];
gdjs.GAMECode.GDBaseObjects2= [];
gdjs.GAMECode.GDBase2Objects1= [];
gdjs.GAMECode.GDBase2Objects2= [];
gdjs.GAMECode.GDCoinObjects1= [];
gdjs.GAMECode.GDCoinObjects2= [];
gdjs.GAMECode.GDWallObjects1= [];
gdjs.GAMECode.GDWallObjects2= [];
gdjs.GAMECode.GDBrickObjects1= [];
gdjs.GAMECode.GDBrickObjects2= [];
gdjs.GAMECode.GDCoinsObjects1= [];
gdjs.GAMECode.GDCoinsObjects2= [];
gdjs.GAMECode.GDPOintsObjects1= [];
gdjs.GAMECode.GDPOintsObjects2= [];
gdjs.GAMECode.GDLevelObjects1= [];
gdjs.GAMECode.GDLevelObjects2= [];
gdjs.GAMECode.GDFlyenemyObjects1= [];
gdjs.GAMECode.GDFlyenemyObjects2= [];
gdjs.GAMECode.GDLeftObjects1= [];
gdjs.GAMECode.GDLeftObjects2= [];
gdjs.GAMECode.GDRightObjects1= [];
gdjs.GAMECode.GDRightObjects2= [];
gdjs.GAMECode.GDtextnoticeObjects1= [];
gdjs.GAMECode.GDtextnoticeObjects2= [];
gdjs.GAMECode.GDskyObjects1= [];
gdjs.GAMECode.GDskyObjects2= [];
gdjs.GAMECode.GDbridge1Objects1= [];
gdjs.GAMECode.GDbridge1Objects2= [];
gdjs.GAMECode.GDbridge2Objects1= [];
gdjs.GAMECode.GDbridge2Objects2= [];
gdjs.GAMECode.GDNewObjectObjects1= [];
gdjs.GAMECode.GDNewObjectObjects2= [];
gdjs.GAMECode.GDDEADObjects1= [];
gdjs.GAMECode.GDDEADObjects2= [];
gdjs.GAMECode.GDdeadObjects1= [];
gdjs.GAMECode.GDdeadObjects2= [];
gdjs.GAMECode.GDBACKObjects1= [];
gdjs.GAMECode.GDBACKObjects2= [];
gdjs.GAMECode.GDNewObject2Objects1= [];
gdjs.GAMECode.GDNewObject2Objects2= [];
gdjs.GAMECode.GDLivesObjects1= [];
gdjs.GAMECode.GDLivesObjects2= [];
gdjs.GAMECode.GDlivespointObjects1= [];
gdjs.GAMECode.GDlivespointObjects2= [];
gdjs.GAMECode.GDENTERPLAYObjects1= [];
gdjs.GAMECode.GDENTERPLAYObjects2= [];
gdjs.GAMECode.GDNewObject3Objects1= [];
gdjs.GAMECode.GDNewObject3Objects2= [];
gdjs.GAMECode.GDdoorObjects1= [];
gdjs.GAMECode.GDdoorObjects2= [];
gdjs.GAMECode.GDNewObject5Objects1= [];
gdjs.GAMECode.GDNewObject5Objects2= [];
gdjs.GAMECode.GDcloudObjects1= [];
gdjs.GAMECode.GDcloudObjects2= [];
gdjs.GAMECode.GDbushObjects1= [];
gdjs.GAMECode.GDbushObjects2= [];
gdjs.GAMECode.GDcactusObjects1= [];
gdjs.GAMECode.GDcactusObjects2= [];

gdjs.GAMECode.conditionTrue_0 = {val:false};
gdjs.GAMECode.condition0IsTrue_0 = {val:false};
gdjs.GAMECode.condition1IsTrue_0 = {val:false};
gdjs.GAMECode.condition2IsTrue_0 = {val:false};


gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GAMECode.GDPlayerObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.GAMECode.GDCoinObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDFlyenemyObjects1Objects = Hashtable.newFrom({"Flyenemy": gdjs.GAMECode.GDFlyenemyObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDLeftObjects1Objects = Hashtable.newFrom({"Left": gdjs.GAMECode.GDLeftObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDFlyenemyObjects1Objects = Hashtable.newFrom({"Flyenemy": gdjs.GAMECode.GDFlyenemyObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDRightObjects1Objects = Hashtable.newFrom({"Right": gdjs.GAMECode.GDRightObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GAMECode.GDPlayerObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDFlyenemyObjects1Objects = Hashtable.newFrom({"Flyenemy": gdjs.GAMECode.GDFlyenemyObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GAMECode.GDPlayerObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.GAMECode.GDNewObjectObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GAMECode.GDPlayerObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.GAMECode.GDNewObjectObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.GAMECode.GDBACKObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.GAMECode.GDBACKObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDENTERPLAYObjects1Objects = Hashtable.newFrom({"ENTERPLAY": gdjs.GAMECode.GDENTERPLAYObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDENTERPLAYObjects1Objects = Hashtable.newFrom({"ENTERPLAY": gdjs.GAMECode.GDENTERPLAYObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GAMECode.GDPlayerObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDNewObject3Objects1Objects = Hashtable.newFrom({"NewObject3": gdjs.GAMECode.GDNewObject3Objects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GAMECode.GDPlayerObjects1});gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDdoorObjects1Objects = Hashtable.newFrom({"door": gdjs.GAMECode.GDdoorObjects1});gdjs.GAMECode.eventsList0x5b7a18 = function(runtimeScene) {

{


{
}

}


{

gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
gdjs.GAMECode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GAMECode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GAMECode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.GAMECode.condition0IsTrue_0.val = true;
        gdjs.GAMECode.GDPlayerObjects1[k] = gdjs.GAMECode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GAMECode.GDPlayerObjects1.length = k;}if ( gdjs.GAMECode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GAMECode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GAMECode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.GAMECode.condition1IsTrue_0.val = true;
        gdjs.GAMECode.GDPlayerObjects1[k] = gdjs.GAMECode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GAMECode.GDPlayerObjects1.length = k;}}
if (gdjs.GAMECode.condition1IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDPlayerObjects1[i].setAnimation(2);
}
}}

}


{

gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
gdjs.GAMECode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GAMECode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GAMECode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.GAMECode.condition0IsTrue_0.val = true;
        gdjs.GAMECode.GDPlayerObjects1[k] = gdjs.GAMECode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GAMECode.GDPlayerObjects1.length = k;}if ( gdjs.GAMECode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GAMECode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.GAMECode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.GAMECode.condition1IsTrue_0.val = true;
        gdjs.GAMECode.GDPlayerObjects1[k] = gdjs.GAMECode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GAMECode.GDPlayerObjects1.length = k;}}
if (gdjs.GAMECode.condition1IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDPlayerObjects1[i].setAnimation(0);
}
}}

}


{

gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GAMECode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GAMECode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.GAMECode.condition0IsTrue_0.val = true;
        gdjs.GAMECode.GDPlayerObjects1[k] = gdjs.GAMECode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GAMECode.GDPlayerObjects1.length = k;}if (gdjs.GAMECode.condition0IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDPlayerObjects1[i].setAnimation(1);
}
}}

}


{


gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.GAMECode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDPlayerObjects1[i].flipX(true);
}
}}

}


{


gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.GAMECode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDPlayerObjects1[i].flipX(false);
}
}}

}


{


{
gdjs.GAMECode.GDDEADObjects1.createFrom(runtimeScene.getObjects("DEAD"));
gdjs.GAMECode.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));
gdjs.GAMECode.GDLeftObjects1.createFrom(runtimeScene.getObjects("Left"));
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.GAMECode.GDRightObjects1.createFrom(runtimeScene.getObjects("Right"));
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GAMECode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GAMECode.GDPlayerObjects1[0].getPointX("")), "", 0);
}{for(var i = 0, len = gdjs.GAMECode.GDLeftObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GAMECode.GDRightObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDRightObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GAMECode.GDDEADObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDDEADObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GAMECode.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDENTERPLAYObjects1[i].hide();
}
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.GAMECode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GAMECode.GDPlayerObjects1[0].getPointY("")), "", 0);
}}

}


{

gdjs.GAMECode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDCoinObjects1Objects, false, runtimeScene, true);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDCoinObjects1 */
gdjs.GAMECode.GDPOintsObjects1.createFrom(runtimeScene.getObjects("POints"));
/* Reuse gdjs.GAMECode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GAMECode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDPlayerObjects1[i].returnVariable(gdjs.GAMECode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.GAMECode.GDPOintsObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDPOintsObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.GAMECode.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GAMECode.GDPlayerObjects1[0].getVariables()).getFromIndex(0))));
}
}}

}


{

gdjs.GAMECode.GDFlyenemyObjects1.createFrom(runtimeScene.getObjects("Flyenemy"));
gdjs.GAMECode.GDLeftObjects1.createFrom(runtimeScene.getObjects("Left"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDFlyenemyObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDLeftObjects1Objects, false, runtimeScene, false);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDFlyenemyObjects1 */
gdjs.GAMECode.GDRightObjects1.createFrom(runtimeScene.getObjects("Right"));
{for(var i = 0, len = gdjs.GAMECode.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDFlyenemyObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.GAMECode.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDFlyenemyObjects1[i].addForceTowardObject((gdjs.GAMECode.GDRightObjects1.length !== 0 ? gdjs.GAMECode.GDRightObjects1[0] : null), 200, 1);
}
}}

}


{

gdjs.GAMECode.GDFlyenemyObjects1.createFrom(runtimeScene.getObjects("Flyenemy"));
gdjs.GAMECode.GDRightObjects1.createFrom(runtimeScene.getObjects("Right"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDFlyenemyObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDRightObjects1Objects, false, runtimeScene, false);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDFlyenemyObjects1 */
gdjs.GAMECode.GDLeftObjects1.createFrom(runtimeScene.getObjects("Left"));
{for(var i = 0, len = gdjs.GAMECode.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDFlyenemyObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.GAMECode.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDFlyenemyObjects1[i].addForceTowardObject((gdjs.GAMECode.GDLeftObjects1.length !== 0 ? gdjs.GAMECode.GDLeftObjects1[0] : null), 200, 1);
}
}}

}


{

gdjs.GAMECode.GDFlyenemyObjects1.createFrom(runtimeScene.getObjects("Flyenemy"));
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDFlyenemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
}

}


{

gdjs.GAMECode.GDNewObjectObjects1.createFrom(runtimeScene.getObjects("NewObject"));
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDNewObjectObjects1Objects, false, runtimeScene, false);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
gdjs.GAMECode.GDDEADObjects1.createFrom(runtimeScene.getObjects("DEAD"));
{for(var i = 0, len = gdjs.GAMECode.GDDEADObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDDEADObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.GAMECode.GDNewObjectObjects1.createFrom(runtimeScene.getObjects("NewObject"));
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDNewObjectObjects1Objects, false, runtimeScene, false);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
gdjs.GAMECode.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));
{for(var i = 0, len = gdjs.GAMECode.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDENTERPLAYObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.GAMECode.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDBACKObjects1Objects, runtimeScene, true, true);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDBACKObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDBACKObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDBACKObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.GAMECode.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
gdjs.GAMECode.condition1IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDBACKObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GAMECode.condition0IsTrue_0.val ) {
{
gdjs.GAMECode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.GAMECode.condition1IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDBACKObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDBACKObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDBACKObjects1[i].setColor("250;10;10");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MENUS", false);
}}

}


{


{
}

}


{

gdjs.GAMECode.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDENTERPLAYObjects1Objects, runtimeScene, true, true);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDENTERPLAYObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDENTERPLAYObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.GAMECode.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
gdjs.GAMECode.condition1IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDENTERPLAYObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GAMECode.condition0IsTrue_0.val ) {
{
gdjs.GAMECode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.GAMECode.condition1IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDENTERPLAYObjects1 */
{for(var i = 0, len = gdjs.GAMECode.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.GAMECode.GDENTERPLAYObjects1[i].setColor("236;7;7");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GAME", false);
}}

}


{

gdjs.GAMECode.GDNewObject3Objects1.createFrom(runtimeScene.getObjects("NewObject3"));
gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDNewObject3Objects1Objects, false, runtimeScene, false);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
/* Reuse gdjs.GAMECode.GDPlayerObjects1 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.GAMECode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GAMECode.GDPlayerObjects1[0].getPointY("")), "", 0);
}}

}


{

gdjs.GAMECode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.GAMECode.GDdoorObjects1.createFrom(runtimeScene.getObjects("door"));

gdjs.GAMECode.condition0IsTrue_0.val = false;
{
gdjs.GAMECode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDPlayerObjects1Objects, gdjs.GAMECode.mapOfGDgdjs_46GAMECode_46GDdoorObjects1Objects, false, runtimeScene, false);
}if (gdjs.GAMECode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level2", false);
}}

}


{


gdjs.GAMECode.condition0IsTrue_0.val = false;
if (gdjs.GAMECode.condition0IsTrue_0.val) {
{}}

}


{


gdjs.GAMECode.condition0IsTrue_0.val = false;
gdjs.GAMECode.condition1IsTrue_0.val = false;
if ( gdjs.GAMECode.condition0IsTrue_0.val ) {
{
gdjs.GAMECode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.GAMECode.condition1IsTrue_0.val) {
{}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PAUSE");
}}

}


}; //End of gdjs.GAMECode.eventsList0x5b7a18


gdjs.GAMECode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GAMECode.GDfinalbkObjects1.length = 0;
gdjs.GAMECode.GDfinalbkObjects2.length = 0;
gdjs.GAMECode.GDPlayerObjects1.length = 0;
gdjs.GAMECode.GDPlayerObjects2.length = 0;
gdjs.GAMECode.GDBaseObjects1.length = 0;
gdjs.GAMECode.GDBaseObjects2.length = 0;
gdjs.GAMECode.GDBase2Objects1.length = 0;
gdjs.GAMECode.GDBase2Objects2.length = 0;
gdjs.GAMECode.GDCoinObjects1.length = 0;
gdjs.GAMECode.GDCoinObjects2.length = 0;
gdjs.GAMECode.GDWallObjects1.length = 0;
gdjs.GAMECode.GDWallObjects2.length = 0;
gdjs.GAMECode.GDBrickObjects1.length = 0;
gdjs.GAMECode.GDBrickObjects2.length = 0;
gdjs.GAMECode.GDCoinsObjects1.length = 0;
gdjs.GAMECode.GDCoinsObjects2.length = 0;
gdjs.GAMECode.GDPOintsObjects1.length = 0;
gdjs.GAMECode.GDPOintsObjects2.length = 0;
gdjs.GAMECode.GDLevelObjects1.length = 0;
gdjs.GAMECode.GDLevelObjects2.length = 0;
gdjs.GAMECode.GDFlyenemyObjects1.length = 0;
gdjs.GAMECode.GDFlyenemyObjects2.length = 0;
gdjs.GAMECode.GDLeftObjects1.length = 0;
gdjs.GAMECode.GDLeftObjects2.length = 0;
gdjs.GAMECode.GDRightObjects1.length = 0;
gdjs.GAMECode.GDRightObjects2.length = 0;
gdjs.GAMECode.GDtextnoticeObjects1.length = 0;
gdjs.GAMECode.GDtextnoticeObjects2.length = 0;
gdjs.GAMECode.GDskyObjects1.length = 0;
gdjs.GAMECode.GDskyObjects2.length = 0;
gdjs.GAMECode.GDbridge1Objects1.length = 0;
gdjs.GAMECode.GDbridge1Objects2.length = 0;
gdjs.GAMECode.GDbridge2Objects1.length = 0;
gdjs.GAMECode.GDbridge2Objects2.length = 0;
gdjs.GAMECode.GDNewObjectObjects1.length = 0;
gdjs.GAMECode.GDNewObjectObjects2.length = 0;
gdjs.GAMECode.GDDEADObjects1.length = 0;
gdjs.GAMECode.GDDEADObjects2.length = 0;
gdjs.GAMECode.GDdeadObjects1.length = 0;
gdjs.GAMECode.GDdeadObjects2.length = 0;
gdjs.GAMECode.GDBACKObjects1.length = 0;
gdjs.GAMECode.GDBACKObjects2.length = 0;
gdjs.GAMECode.GDNewObject2Objects1.length = 0;
gdjs.GAMECode.GDNewObject2Objects2.length = 0;
gdjs.GAMECode.GDLivesObjects1.length = 0;
gdjs.GAMECode.GDLivesObjects2.length = 0;
gdjs.GAMECode.GDlivespointObjects1.length = 0;
gdjs.GAMECode.GDlivespointObjects2.length = 0;
gdjs.GAMECode.GDENTERPLAYObjects1.length = 0;
gdjs.GAMECode.GDENTERPLAYObjects2.length = 0;
gdjs.GAMECode.GDNewObject3Objects1.length = 0;
gdjs.GAMECode.GDNewObject3Objects2.length = 0;
gdjs.GAMECode.GDdoorObjects1.length = 0;
gdjs.GAMECode.GDdoorObjects2.length = 0;
gdjs.GAMECode.GDNewObject5Objects1.length = 0;
gdjs.GAMECode.GDNewObject5Objects2.length = 0;
gdjs.GAMECode.GDcloudObjects1.length = 0;
gdjs.GAMECode.GDcloudObjects2.length = 0;
gdjs.GAMECode.GDbushObjects1.length = 0;
gdjs.GAMECode.GDbushObjects2.length = 0;
gdjs.GAMECode.GDcactusObjects1.length = 0;
gdjs.GAMECode.GDcactusObjects2.length = 0;

gdjs.GAMECode.eventsList0x5b7a18(runtimeScene);
return;

}

gdjs['GAMECode'] = gdjs.GAMECode;
