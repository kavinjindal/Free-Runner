gdjs.CREDITSCode = {};
gdjs.CREDITSCode.GDfinalbkObjects1= [];
gdjs.CREDITSCode.GDfinalbkObjects2= [];
gdjs.CREDITSCode.GDNewObjectObjects1= [];
gdjs.CREDITSCode.GDNewObjectObjects2= [];
gdjs.CREDITSCode.GDcREDITSObjects1= [];
gdjs.CREDITSCode.GDcREDITSObjects2= [];
gdjs.CREDITSCode.GDDEVELOPEDObjects1= [];
gdjs.CREDITSCode.GDDEVELOPEDObjects2= [];
gdjs.CREDITSCode.GDKAVINObjects1= [];
gdjs.CREDITSCode.GDKAVINObjects2= [];
gdjs.CREDITSCode.GDVERSIONObjects1= [];
gdjs.CREDITSCode.GDVERSIONObjects2= [];
gdjs.CREDITSCode.GDVERSIONNOPObjects1= [];
gdjs.CREDITSCode.GDVERSIONNOPObjects2= [];
gdjs.CREDITSCode.GDREPORTObjects1= [];
gdjs.CREDITSCode.GDREPORTObjects2= [];
gdjs.CREDITSCode.GDEMAILObjects1= [];
gdjs.CREDITSCode.GDEMAILObjects2= [];
gdjs.CREDITSCode.GDBACKObjects1= [];
gdjs.CREDITSCode.GDBACKObjects2= [];
gdjs.CREDITSCode.GDNewObject2Objects1= [];
gdjs.CREDITSCode.GDNewObject2Objects2= [];
gdjs.CREDITSCode.GDNewObject3Objects1= [];
gdjs.CREDITSCode.GDNewObject3Objects2= [];

gdjs.CREDITSCode.conditionTrue_0 = {val:false};
gdjs.CREDITSCode.condition0IsTrue_0 = {val:false};
gdjs.CREDITSCode.condition1IsTrue_0 = {val:false};
gdjs.CREDITSCode.condition2IsTrue_0 = {val:false};


gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDEMAILObjects1Objects = Hashtable.newFrom({"EMAIL": gdjs.CREDITSCode.GDEMAILObjects1});gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.CREDITSCode.GDNewObjectObjects1});gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.CREDITSCode.GDBACKObjects1});gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.CREDITSCode.GDBACKObjects1});gdjs.CREDITSCode.eventsList0x5b7a18 = function(runtimeScene) {

{

gdjs.CREDITSCode.GDEMAILObjects1.createFrom(runtimeScene.getObjects("EMAIL"));

gdjs.CREDITSCode.condition0IsTrue_0.val = false;
{
gdjs.CREDITSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDEMAILObjects1Objects, runtimeScene, true, true);
}if (gdjs.CREDITSCode.condition0IsTrue_0.val) {
/* Reuse gdjs.CREDITSCode.GDEMAILObjects1 */
{for(var i = 0, len = gdjs.CREDITSCode.GDEMAILObjects1.length ;i < len;++i) {
    gdjs.CREDITSCode.GDEMAILObjects1[i].setColor("253;6;6");
}
}}

}


{

gdjs.CREDITSCode.GDNewObjectObjects1.createFrom(runtimeScene.getObjects("NewObject"));

gdjs.CREDITSCode.condition0IsTrue_0.val = false;
{
gdjs.CREDITSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDNewObjectObjects1Objects, runtimeScene, true, false);
}if (gdjs.CREDITSCode.condition0IsTrue_0.val) {
gdjs.CREDITSCode.GDEMAILObjects1.createFrom(runtimeScene.getObjects("EMAIL"));
{for(var i = 0, len = gdjs.CREDITSCode.GDEMAILObjects1.length ;i < len;++i) {
    gdjs.CREDITSCode.GDEMAILObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.CREDITSCode.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.CREDITSCode.condition0IsTrue_0.val = false;
{
gdjs.CREDITSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDBACKObjects1Objects, runtimeScene, true, true);
}if (gdjs.CREDITSCode.condition0IsTrue_0.val) {
/* Reuse gdjs.CREDITSCode.GDBACKObjects1 */
{for(var i = 0, len = gdjs.CREDITSCode.GDBACKObjects1.length ;i < len;++i) {
    gdjs.CREDITSCode.GDBACKObjects1[i].setColor("253;3;3");
}
}}

}


{

gdjs.CREDITSCode.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.CREDITSCode.condition0IsTrue_0.val = false;
gdjs.CREDITSCode.condition1IsTrue_0.val = false;
{
gdjs.CREDITSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.CREDITSCode.mapOfGDgdjs_46CREDITSCode_46GDBACKObjects1Objects, runtimeScene, true, false);
}if ( gdjs.CREDITSCode.condition0IsTrue_0.val ) {
{
gdjs.CREDITSCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.CREDITSCode.condition1IsTrue_0.val) {
/* Reuse gdjs.CREDITSCode.GDBACKObjects1 */
{for(var i = 0, len = gdjs.CREDITSCode.GDBACKObjects1.length ;i < len;++i) {
    gdjs.CREDITSCode.GDBACKObjects1[i].setColor("243;4;4");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MENUS", false);
}}

}


}; //End of gdjs.CREDITSCode.eventsList0x5b7a18


gdjs.CREDITSCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CREDITSCode.GDfinalbkObjects1.length = 0;
gdjs.CREDITSCode.GDfinalbkObjects2.length = 0;
gdjs.CREDITSCode.GDNewObjectObjects1.length = 0;
gdjs.CREDITSCode.GDNewObjectObjects2.length = 0;
gdjs.CREDITSCode.GDcREDITSObjects1.length = 0;
gdjs.CREDITSCode.GDcREDITSObjects2.length = 0;
gdjs.CREDITSCode.GDDEVELOPEDObjects1.length = 0;
gdjs.CREDITSCode.GDDEVELOPEDObjects2.length = 0;
gdjs.CREDITSCode.GDKAVINObjects1.length = 0;
gdjs.CREDITSCode.GDKAVINObjects2.length = 0;
gdjs.CREDITSCode.GDVERSIONObjects1.length = 0;
gdjs.CREDITSCode.GDVERSIONObjects2.length = 0;
gdjs.CREDITSCode.GDVERSIONNOPObjects1.length = 0;
gdjs.CREDITSCode.GDVERSIONNOPObjects2.length = 0;
gdjs.CREDITSCode.GDREPORTObjects1.length = 0;
gdjs.CREDITSCode.GDREPORTObjects2.length = 0;
gdjs.CREDITSCode.GDEMAILObjects1.length = 0;
gdjs.CREDITSCode.GDEMAILObjects2.length = 0;
gdjs.CREDITSCode.GDBACKObjects1.length = 0;
gdjs.CREDITSCode.GDBACKObjects2.length = 0;
gdjs.CREDITSCode.GDNewObject2Objects1.length = 0;
gdjs.CREDITSCode.GDNewObject2Objects2.length = 0;
gdjs.CREDITSCode.GDNewObject3Objects1.length = 0;
gdjs.CREDITSCode.GDNewObject3Objects2.length = 0;

gdjs.CREDITSCode.eventsList0x5b7a18(runtimeScene);
return;

}

gdjs['CREDITSCode'] = gdjs.CREDITSCode;
