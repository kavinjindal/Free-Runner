gdjs.level2Code = {};
gdjs.level2Code.GDfinalbkObjects1= [];
gdjs.level2Code.GDfinalbkObjects2= [];
gdjs.level2Code.GDPlayerObjects1= [];
gdjs.level2Code.GDPlayerObjects2= [];
gdjs.level2Code.GDBaseObjects1= [];
gdjs.level2Code.GDBaseObjects2= [];
gdjs.level2Code.GDBase2Objects1= [];
gdjs.level2Code.GDBase2Objects2= [];
gdjs.level2Code.GDCoinObjects1= [];
gdjs.level2Code.GDCoinObjects2= [];
gdjs.level2Code.GDWallObjects1= [];
gdjs.level2Code.GDWallObjects2= [];
gdjs.level2Code.GDBrickObjects1= [];
gdjs.level2Code.GDBrickObjects2= [];
gdjs.level2Code.GDCoinsObjects1= [];
gdjs.level2Code.GDCoinsObjects2= [];
gdjs.level2Code.GDPOintsObjects1= [];
gdjs.level2Code.GDPOintsObjects2= [];
gdjs.level2Code.GDLevelObjects1= [];
gdjs.level2Code.GDLevelObjects2= [];
gdjs.level2Code.GDFlyenemyObjects1= [];
gdjs.level2Code.GDFlyenemyObjects2= [];
gdjs.level2Code.GDLeftObjects1= [];
gdjs.level2Code.GDLeftObjects2= [];
gdjs.level2Code.GDRightObjects1= [];
gdjs.level2Code.GDRightObjects2= [];
gdjs.level2Code.GDtextnoticeObjects1= [];
gdjs.level2Code.GDtextnoticeObjects2= [];
gdjs.level2Code.GDskyObjects1= [];
gdjs.level2Code.GDskyObjects2= [];
gdjs.level2Code.GDbridge1Objects1= [];
gdjs.level2Code.GDbridge1Objects2= [];
gdjs.level2Code.GDbridge2Objects1= [];
gdjs.level2Code.GDbridge2Objects2= [];
gdjs.level2Code.GDNewObjectObjects1= [];
gdjs.level2Code.GDNewObjectObjects2= [];
gdjs.level2Code.GDDEADObjects1= [];
gdjs.level2Code.GDDEADObjects2= [];
gdjs.level2Code.GDdeadObjects1= [];
gdjs.level2Code.GDdeadObjects2= [];
gdjs.level2Code.GDBACKObjects1= [];
gdjs.level2Code.GDBACKObjects2= [];
gdjs.level2Code.GDNewObject2Objects1= [];
gdjs.level2Code.GDNewObject2Objects2= [];
gdjs.level2Code.GDLivesObjects1= [];
gdjs.level2Code.GDLivesObjects2= [];
gdjs.level2Code.GDlivespointObjects1= [];
gdjs.level2Code.GDlivespointObjects2= [];
gdjs.level2Code.GDENTERPLAYObjects1= [];
gdjs.level2Code.GDENTERPLAYObjects2= [];
gdjs.level2Code.GDNewObject3Objects1= [];
gdjs.level2Code.GDNewObject3Objects2= [];
gdjs.level2Code.GDdoorObjects1= [];
gdjs.level2Code.GDdoorObjects2= [];
gdjs.level2Code.GDBACKGROUNDObjects1= [];
gdjs.level2Code.GDBACKGROUNDObjects2= [];

gdjs.level2Code.conditionTrue_0 = {val:false};
gdjs.level2Code.condition0IsTrue_0 = {val:false};
gdjs.level2Code.condition1IsTrue_0 = {val:false};
gdjs.level2Code.condition2IsTrue_0 = {val:false};


gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.level2Code.GDPlayerObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.level2Code.GDCoinObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDFlyenemyObjects1Objects = Hashtable.newFrom({"Flyenemy": gdjs.level2Code.GDFlyenemyObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDLeftObjects1Objects = Hashtable.newFrom({"Left": gdjs.level2Code.GDLeftObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDFlyenemyObjects1Objects = Hashtable.newFrom({"Flyenemy": gdjs.level2Code.GDFlyenemyObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDRightObjects1Objects = Hashtable.newFrom({"Right": gdjs.level2Code.GDRightObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.level2Code.GDPlayerObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDFlyenemyObjects1Objects = Hashtable.newFrom({"Flyenemy": gdjs.level2Code.GDFlyenemyObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.level2Code.GDPlayerObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.level2Code.GDNewObjectObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.level2Code.GDPlayerObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.level2Code.GDNewObjectObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.level2Code.GDBACKObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.level2Code.GDBACKObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDENTERPLAYObjects1Objects = Hashtable.newFrom({"ENTERPLAY": gdjs.level2Code.GDENTERPLAYObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDENTERPLAYObjects1Objects = Hashtable.newFrom({"ENTERPLAY": gdjs.level2Code.GDENTERPLAYObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.level2Code.GDPlayerObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDNewObject3Objects1Objects = Hashtable.newFrom({"NewObject3": gdjs.level2Code.GDNewObject3Objects1});gdjs.level2Code.eventsList0x5b7a18 = function(runtimeScene) {

{


{
}

}


{

gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
gdjs.level2Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.level2Code.condition0IsTrue_0.val = true;
        gdjs.level2Code.GDPlayerObjects1[k] = gdjs.level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.level2Code.GDPlayerObjects1.length = k;}if ( gdjs.level2Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.level2Code.condition1IsTrue_0.val = true;
        gdjs.level2Code.GDPlayerObjects1[k] = gdjs.level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.level2Code.GDPlayerObjects1.length = k;}}
if (gdjs.level2Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDPlayerObjects1[i].setAnimation(2);
}
}}

}


{

gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
gdjs.level2Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.level2Code.condition0IsTrue_0.val = true;
        gdjs.level2Code.GDPlayerObjects1[k] = gdjs.level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.level2Code.GDPlayerObjects1.length = k;}if ( gdjs.level2Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.level2Code.condition1IsTrue_0.val = true;
        gdjs.level2Code.GDPlayerObjects1[k] = gdjs.level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.level2Code.GDPlayerObjects1.length = k;}}
if (gdjs.level2Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDPlayerObjects1[i].setAnimation(0);
}
}}

}


{

gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.level2Code.condition0IsTrue_0.val = true;
        gdjs.level2Code.GDPlayerObjects1[k] = gdjs.level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.level2Code.GDPlayerObjects1.length = k;}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDPlayerObjects1[i].setAnimation(1);
}
}}

}


{


gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDPlayerObjects1[i].flipX(true);
}
}}

}


{


gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDPlayerObjects1[i].flipX(false);
}
}}

}


{


{
gdjs.level2Code.GDDEADObjects1.createFrom(runtimeScene.getObjects("DEAD"));
gdjs.level2Code.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));
gdjs.level2Code.GDLeftObjects1.createFrom(runtimeScene.getObjects("Left"));
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.level2Code.GDRightObjects1.createFrom(runtimeScene.getObjects("Right"));
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.level2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.level2Code.GDPlayerObjects1[0].getPointX("")), "", 0);
}{for(var i = 0, len = gdjs.level2Code.GDLeftObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.level2Code.GDRightObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDRightObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.level2Code.GDDEADObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDDEADObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.level2Code.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDENTERPLAYObjects1[i].hide();
}
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.level2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.level2Code.GDPlayerObjects1[0].getPointY("")), "", 0);
}}

}


{

gdjs.level2Code.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDCoinObjects1Objects, false, runtimeScene, true);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDCoinObjects1 */
gdjs.level2Code.GDPOintsObjects1.createFrom(runtimeScene.getObjects("POints"));
/* Reuse gdjs.level2Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDCoinObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDPlayerObjects1[i].returnVariable(gdjs.level2Code.GDPlayerObjects1[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.level2Code.GDPOintsObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDPOintsObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.level2Code.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.level2Code.GDPlayerObjects1[0].getVariables()).getFromIndex(0))));
}
}}

}


{

gdjs.level2Code.GDFlyenemyObjects1.createFrom(runtimeScene.getObjects("Flyenemy"));
gdjs.level2Code.GDLeftObjects1.createFrom(runtimeScene.getObjects("Left"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDFlyenemyObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDLeftObjects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDFlyenemyObjects1 */
gdjs.level2Code.GDRightObjects1.createFrom(runtimeScene.getObjects("Right"));
{for(var i = 0, len = gdjs.level2Code.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDFlyenemyObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.level2Code.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDFlyenemyObjects1[i].addForceTowardObject((gdjs.level2Code.GDRightObjects1.length !== 0 ? gdjs.level2Code.GDRightObjects1[0] : null), 200, 1);
}
}}

}


{

gdjs.level2Code.GDFlyenemyObjects1.createFrom(runtimeScene.getObjects("Flyenemy"));
gdjs.level2Code.GDRightObjects1.createFrom(runtimeScene.getObjects("Right"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDFlyenemyObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDRightObjects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDFlyenemyObjects1 */
gdjs.level2Code.GDLeftObjects1.createFrom(runtimeScene.getObjects("Left"));
{for(var i = 0, len = gdjs.level2Code.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDFlyenemyObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.level2Code.GDFlyenemyObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDFlyenemyObjects1[i].addForceTowardObject((gdjs.level2Code.GDLeftObjects1.length !== 0 ? gdjs.level2Code.GDLeftObjects1[0] : null), 200, 1);
}
}}

}


{

gdjs.level2Code.GDFlyenemyObjects1.createFrom(runtimeScene.getObjects("Flyenemy"));
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDFlyenemyObjects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
}

}


{

gdjs.level2Code.GDNewObjectObjects1.createFrom(runtimeScene.getObjects("NewObject"));
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDNewObjectObjects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.level2Code.GDDEADObjects1.createFrom(runtimeScene.getObjects("DEAD"));
{for(var i = 0, len = gdjs.level2Code.GDDEADObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDDEADObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.level2Code.GDNewObjectObjects1.createFrom(runtimeScene.getObjects("NewObject"));
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDNewObjectObjects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.level2Code.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));
{for(var i = 0, len = gdjs.level2Code.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDENTERPLAYObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.level2Code.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDBACKObjects1Objects, runtimeScene, true, true);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDBACKObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDBACKObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDBACKObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.level2Code.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.level2Code.condition0IsTrue_0.val = false;
gdjs.level2Code.condition1IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDBACKObjects1Objects, runtimeScene, true, false);
}if ( gdjs.level2Code.condition0IsTrue_0.val ) {
{
gdjs.level2Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.level2Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDBACKObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDBACKObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDBACKObjects1[i].setColor("250;10;10");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MENUS", false);
}}

}


{


{
}

}


{

gdjs.level2Code.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDENTERPLAYObjects1Objects, runtimeScene, true, true);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDENTERPLAYObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDENTERPLAYObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.level2Code.GDENTERPLAYObjects1.createFrom(runtimeScene.getObjects("ENTERPLAY"));

gdjs.level2Code.condition0IsTrue_0.val = false;
gdjs.level2Code.condition1IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDENTERPLAYObjects1Objects, runtimeScene, true, false);
}if ( gdjs.level2Code.condition0IsTrue_0.val ) {
{
gdjs.level2Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.level2Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDENTERPLAYObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDENTERPLAYObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDENTERPLAYObjects1[i].setColor("236;7;7");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GAME", false);
}}

}


{

gdjs.level2Code.GDNewObject3Objects1.createFrom(runtimeScene.getObjects("NewObject3"));
gdjs.level2Code.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDPlayerObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDNewObject3Objects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDPlayerObjects1 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.level2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.level2Code.GDPlayerObjects1[0].getPointY("")), "", 0);
}}

}


}; //End of gdjs.level2Code.eventsList0x5b7a18


gdjs.level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level2Code.GDfinalbkObjects1.length = 0;
gdjs.level2Code.GDfinalbkObjects2.length = 0;
gdjs.level2Code.GDPlayerObjects1.length = 0;
gdjs.level2Code.GDPlayerObjects2.length = 0;
gdjs.level2Code.GDBaseObjects1.length = 0;
gdjs.level2Code.GDBaseObjects2.length = 0;
gdjs.level2Code.GDBase2Objects1.length = 0;
gdjs.level2Code.GDBase2Objects2.length = 0;
gdjs.level2Code.GDCoinObjects1.length = 0;
gdjs.level2Code.GDCoinObjects2.length = 0;
gdjs.level2Code.GDWallObjects1.length = 0;
gdjs.level2Code.GDWallObjects2.length = 0;
gdjs.level2Code.GDBrickObjects1.length = 0;
gdjs.level2Code.GDBrickObjects2.length = 0;
gdjs.level2Code.GDCoinsObjects1.length = 0;
gdjs.level2Code.GDCoinsObjects2.length = 0;
gdjs.level2Code.GDPOintsObjects1.length = 0;
gdjs.level2Code.GDPOintsObjects2.length = 0;
gdjs.level2Code.GDLevelObjects1.length = 0;
gdjs.level2Code.GDLevelObjects2.length = 0;
gdjs.level2Code.GDFlyenemyObjects1.length = 0;
gdjs.level2Code.GDFlyenemyObjects2.length = 0;
gdjs.level2Code.GDLeftObjects1.length = 0;
gdjs.level2Code.GDLeftObjects2.length = 0;
gdjs.level2Code.GDRightObjects1.length = 0;
gdjs.level2Code.GDRightObjects2.length = 0;
gdjs.level2Code.GDtextnoticeObjects1.length = 0;
gdjs.level2Code.GDtextnoticeObjects2.length = 0;
gdjs.level2Code.GDskyObjects1.length = 0;
gdjs.level2Code.GDskyObjects2.length = 0;
gdjs.level2Code.GDbridge1Objects1.length = 0;
gdjs.level2Code.GDbridge1Objects2.length = 0;
gdjs.level2Code.GDbridge2Objects1.length = 0;
gdjs.level2Code.GDbridge2Objects2.length = 0;
gdjs.level2Code.GDNewObjectObjects1.length = 0;
gdjs.level2Code.GDNewObjectObjects2.length = 0;
gdjs.level2Code.GDDEADObjects1.length = 0;
gdjs.level2Code.GDDEADObjects2.length = 0;
gdjs.level2Code.GDdeadObjects1.length = 0;
gdjs.level2Code.GDdeadObjects2.length = 0;
gdjs.level2Code.GDBACKObjects1.length = 0;
gdjs.level2Code.GDBACKObjects2.length = 0;
gdjs.level2Code.GDNewObject2Objects1.length = 0;
gdjs.level2Code.GDNewObject2Objects2.length = 0;
gdjs.level2Code.GDLivesObjects1.length = 0;
gdjs.level2Code.GDLivesObjects2.length = 0;
gdjs.level2Code.GDlivespointObjects1.length = 0;
gdjs.level2Code.GDlivespointObjects2.length = 0;
gdjs.level2Code.GDENTERPLAYObjects1.length = 0;
gdjs.level2Code.GDENTERPLAYObjects2.length = 0;
gdjs.level2Code.GDNewObject3Objects1.length = 0;
gdjs.level2Code.GDNewObject3Objects2.length = 0;
gdjs.level2Code.GDdoorObjects1.length = 0;
gdjs.level2Code.GDdoorObjects2.length = 0;
gdjs.level2Code.GDBACKGROUNDObjects1.length = 0;
gdjs.level2Code.GDBACKGROUNDObjects2.length = 0;

gdjs.level2Code.eventsList0x5b7a18(runtimeScene);
return;

}

gdjs['level2Code'] = gdjs.level2Code;
