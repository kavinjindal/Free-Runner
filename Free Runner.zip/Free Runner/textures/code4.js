gdjs.HOWTOCode = {};
gdjs.HOWTOCode.GDfinalbkObjects1= [];
gdjs.HOWTOCode.GDfinalbkObjects2= [];
gdjs.HOWTOCode.GDNewObjectObjects1= [];
gdjs.HOWTOCode.GDNewObjectObjects2= [];
gdjs.HOWTOCode.GDHOWTOObjects1= [];
gdjs.HOWTOCode.GDHOWTOObjects2= [];
gdjs.HOWTOCode.GDCONTROLSObjects1= [];
gdjs.HOWTOCode.GDCONTROLSObjects2= [];
gdjs.HOWTOCode.GDRIGHTObjects1= [];
gdjs.HOWTOCode.GDRIGHTObjects2= [];
gdjs.HOWTOCode.GDLEFTObjects1= [];
gdjs.HOWTOCode.GDLEFTObjects2= [];
gdjs.HOWTOCode.GDJUMPObjects1= [];
gdjs.HOWTOCode.GDJUMPObjects2= [];
gdjs.HOWTOCode.GDSPACEBARObjects1= [];
gdjs.HOWTOCode.GDSPACEBARObjects2= [];
gdjs.HOWTOCode.GDBACKObjects1= [];
gdjs.HOWTOCode.GDBACKObjects2= [];

gdjs.HOWTOCode.conditionTrue_0 = {val:false};
gdjs.HOWTOCode.condition0IsTrue_0 = {val:false};
gdjs.HOWTOCode.condition1IsTrue_0 = {val:false};
gdjs.HOWTOCode.condition2IsTrue_0 = {val:false};


gdjs.HOWTOCode.mapOfGDgdjs_46HOWTOCode_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.HOWTOCode.GDBACKObjects1});gdjs.HOWTOCode.mapOfGDgdjs_46HOWTOCode_46GDBACKObjects1Objects = Hashtable.newFrom({"BACK": gdjs.HOWTOCode.GDBACKObjects1});gdjs.HOWTOCode.eventsList0x5b7a18 = function(runtimeScene) {

{

gdjs.HOWTOCode.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.HOWTOCode.condition0IsTrue_0.val = false;
{
gdjs.HOWTOCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.HOWTOCode.mapOfGDgdjs_46HOWTOCode_46GDBACKObjects1Objects, runtimeScene, true, true);
}if (gdjs.HOWTOCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HOWTOCode.GDBACKObjects1 */
{for(var i = 0, len = gdjs.HOWTOCode.GDBACKObjects1.length ;i < len;++i) {
    gdjs.HOWTOCode.GDBACKObjects1[i].setColor("15;15;15");
}
}}

}


{

gdjs.HOWTOCode.GDBACKObjects1.createFrom(runtimeScene.getObjects("BACK"));

gdjs.HOWTOCode.condition0IsTrue_0.val = false;
gdjs.HOWTOCode.condition1IsTrue_0.val = false;
{
gdjs.HOWTOCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.HOWTOCode.mapOfGDgdjs_46HOWTOCode_46GDBACKObjects1Objects, runtimeScene, true, false);
}if ( gdjs.HOWTOCode.condition0IsTrue_0.val ) {
{
gdjs.HOWTOCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.HOWTOCode.condition1IsTrue_0.val) {
/* Reuse gdjs.HOWTOCode.GDBACKObjects1 */
{for(var i = 0, len = gdjs.HOWTOCode.GDBACKObjects1.length ;i < len;++i) {
    gdjs.HOWTOCode.GDBACKObjects1[i].setColor("243;15;15");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MENUS", false);
}}

}


}; //End of gdjs.HOWTOCode.eventsList0x5b7a18


gdjs.HOWTOCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.HOWTOCode.GDfinalbkObjects1.length = 0;
gdjs.HOWTOCode.GDfinalbkObjects2.length = 0;
gdjs.HOWTOCode.GDNewObjectObjects1.length = 0;
gdjs.HOWTOCode.GDNewObjectObjects2.length = 0;
gdjs.HOWTOCode.GDHOWTOObjects1.length = 0;
gdjs.HOWTOCode.GDHOWTOObjects2.length = 0;
gdjs.HOWTOCode.GDCONTROLSObjects1.length = 0;
gdjs.HOWTOCode.GDCONTROLSObjects2.length = 0;
gdjs.HOWTOCode.GDRIGHTObjects1.length = 0;
gdjs.HOWTOCode.GDRIGHTObjects2.length = 0;
gdjs.HOWTOCode.GDLEFTObjects1.length = 0;
gdjs.HOWTOCode.GDLEFTObjects2.length = 0;
gdjs.HOWTOCode.GDJUMPObjects1.length = 0;
gdjs.HOWTOCode.GDJUMPObjects2.length = 0;
gdjs.HOWTOCode.GDSPACEBARObjects1.length = 0;
gdjs.HOWTOCode.GDSPACEBARObjects2.length = 0;
gdjs.HOWTOCode.GDBACKObjects1.length = 0;
gdjs.HOWTOCode.GDBACKObjects2.length = 0;

gdjs.HOWTOCode.eventsList0x5b7a18(runtimeScene);
return;

}

gdjs['HOWTOCode'] = gdjs.HOWTOCode;
