gdjs.PAUSECode = {};
gdjs.PAUSECode.GDfinalbkObjects1= [];
gdjs.PAUSECode.GDfinalbkObjects2= [];
gdjs.PAUSECode.GDNewObjectObjects1= [];
gdjs.PAUSECode.GDNewObjectObjects2= [];
gdjs.PAUSECode.GDPAUSEObjects1= [];
gdjs.PAUSECode.GDPAUSEObjects2= [];
gdjs.PAUSECode.GDRESUMEObjects1= [];
gdjs.PAUSECode.GDRESUMEObjects2= [];
gdjs.PAUSECode.GDQUITObjects1= [];
gdjs.PAUSECode.GDQUITObjects2= [];

gdjs.PAUSECode.conditionTrue_0 = {val:false};
gdjs.PAUSECode.condition0IsTrue_0 = {val:false};
gdjs.PAUSECode.condition1IsTrue_0 = {val:false};
gdjs.PAUSECode.condition2IsTrue_0 = {val:false};


gdjs.PAUSECode.mapOfGDgdjs_46PAUSECode_46GDRESUMEObjects1Objects = Hashtable.newFrom({"RESUME": gdjs.PAUSECode.GDRESUMEObjects1});gdjs.PAUSECode.mapOfGDgdjs_46PAUSECode_46GDRESUMEObjects1Objects = Hashtable.newFrom({"RESUME": gdjs.PAUSECode.GDRESUMEObjects1});gdjs.PAUSECode.eventsList0x5b7a18 = function(runtimeScene) {

{

gdjs.PAUSECode.GDRESUMEObjects1.createFrom(runtimeScene.getObjects("RESUME"));

gdjs.PAUSECode.condition0IsTrue_0.val = false;
{
gdjs.PAUSECode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PAUSECode.mapOfGDgdjs_46PAUSECode_46GDRESUMEObjects1Objects, runtimeScene, true, true);
}if (gdjs.PAUSECode.condition0IsTrue_0.val) {
/* Reuse gdjs.PAUSECode.GDRESUMEObjects1 */
{for(var i = 0, len = gdjs.PAUSECode.GDRESUMEObjects1.length ;i < len;++i) {
    gdjs.PAUSECode.GDRESUMEObjects1[i].setColor("19;18;18");
}
}}

}


{

gdjs.PAUSECode.GDRESUMEObjects1.createFrom(runtimeScene.getObjects("RESUME"));

gdjs.PAUSECode.condition0IsTrue_0.val = false;
gdjs.PAUSECode.condition1IsTrue_0.val = false;
{
gdjs.PAUSECode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.PAUSECode.mapOfGDgdjs_46PAUSECode_46GDRESUMEObjects1Objects, runtimeScene, true, false);
}if ( gdjs.PAUSECode.condition0IsTrue_0.val ) {
{
gdjs.PAUSECode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.PAUSECode.condition1IsTrue_0.val) {
/* Reuse gdjs.PAUSECode.GDRESUMEObjects1 */
{for(var i = 0, len = gdjs.PAUSECode.GDRESUMEObjects1.length ;i < len;++i) {
    gdjs.PAUSECode.GDRESUMEObjects1[i].setColor("245;7;7");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GAME", false);
}}

}


}; //End of gdjs.PAUSECode.eventsList0x5b7a18


gdjs.PAUSECode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PAUSECode.GDfinalbkObjects1.length = 0;
gdjs.PAUSECode.GDfinalbkObjects2.length = 0;
gdjs.PAUSECode.GDNewObjectObjects1.length = 0;
gdjs.PAUSECode.GDNewObjectObjects2.length = 0;
gdjs.PAUSECode.GDPAUSEObjects1.length = 0;
gdjs.PAUSECode.GDPAUSEObjects2.length = 0;
gdjs.PAUSECode.GDRESUMEObjects1.length = 0;
gdjs.PAUSECode.GDRESUMEObjects2.length = 0;
gdjs.PAUSECode.GDQUITObjects1.length = 0;
gdjs.PAUSECode.GDQUITObjects2.length = 0;

gdjs.PAUSECode.eventsList0x5b7a18(runtimeScene);
return;

}

gdjs['PAUSECode'] = gdjs.PAUSECode;
