gdjs.MENUSCode = {};
gdjs.MENUSCode.GDfinalbkObjects1= [];
gdjs.MENUSCode.GDfinalbkObjects2= [];
gdjs.MENUSCode.GDNewObjectObjects1= [];
gdjs.MENUSCode.GDNewObjectObjects2= [];
gdjs.MENUSCode.GDheadingObjects1= [];
gdjs.MENUSCode.GDheadingObjects2= [];
gdjs.MENUSCode.GDSTARTObjects1= [];
gdjs.MENUSCode.GDSTARTObjects2= [];
gdjs.MENUSCode.GDCREDITSObjects1= [];
gdjs.MENUSCode.GDCREDITSObjects2= [];
gdjs.MENUSCode.GDQUITObjects1= [];
gdjs.MENUSCode.GDQUITObjects2= [];
gdjs.MENUSCode.GDhowtoObjects1= [];
gdjs.MENUSCode.GDhowtoObjects2= [];

gdjs.MENUSCode.conditionTrue_0 = {val:false};
gdjs.MENUSCode.condition0IsTrue_0 = {val:false};
gdjs.MENUSCode.condition1IsTrue_0 = {val:false};
gdjs.MENUSCode.condition2IsTrue_0 = {val:false};


gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDSTARTObjects1Objects = Hashtable.newFrom({"START": gdjs.MENUSCode.GDSTARTObjects1});gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDSTARTObjects1Objects = Hashtable.newFrom({"START": gdjs.MENUSCode.GDSTARTObjects1});gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDCREDITSObjects1Objects = Hashtable.newFrom({"CREDITS": gdjs.MENUSCode.GDCREDITSObjects1});gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDCREDITSObjects1Objects = Hashtable.newFrom({"CREDITS": gdjs.MENUSCode.GDCREDITSObjects1});gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDQUITObjects1Objects = Hashtable.newFrom({"QUIT": gdjs.MENUSCode.GDQUITObjects1});gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDQUITObjects1Objects = Hashtable.newFrom({"QUIT": gdjs.MENUSCode.GDQUITObjects1});gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDhowtoObjects1Objects = Hashtable.newFrom({"howto": gdjs.MENUSCode.GDhowtoObjects1});gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDhowtoObjects1Objects = Hashtable.newFrom({"howto": gdjs.MENUSCode.GDhowtoObjects1});gdjs.MENUSCode.eventsList0x5b7a18 = function(runtimeScene) {

{



}


{


{
}

}


{

gdjs.MENUSCode.GDSTARTObjects1.createFrom(runtimeScene.getObjects("START"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDSTARTObjects1Objects, runtimeScene, true, true);
}if (gdjs.MENUSCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MENUSCode.GDSTARTObjects1 */
{for(var i = 0, len = gdjs.MENUSCode.GDSTARTObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDSTARTObjects1[i].setColor("7;7;7");
}
}}

}


{

gdjs.MENUSCode.GDSTARTObjects1.createFrom(runtimeScene.getObjects("START"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
gdjs.MENUSCode.condition1IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDSTARTObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MENUSCode.condition0IsTrue_0.val ) {
{
gdjs.MENUSCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.MENUSCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MENUSCode.GDSTARTObjects1 */
{for(var i = 0, len = gdjs.MENUSCode.GDSTARTObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDSTARTObjects1[i].setColor("238;44;44");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GAME", false);
}}

}


{

gdjs.MENUSCode.GDCREDITSObjects1.createFrom(runtimeScene.getObjects("CREDITS"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDCREDITSObjects1Objects, runtimeScene, true, true);
}if (gdjs.MENUSCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MENUSCode.GDCREDITSObjects1 */
{for(var i = 0, len = gdjs.MENUSCode.GDCREDITSObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDCREDITSObjects1[i].setColor("0;0;0");
}
}}

}


{

gdjs.MENUSCode.GDCREDITSObjects1.createFrom(runtimeScene.getObjects("CREDITS"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
gdjs.MENUSCode.condition1IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDCREDITSObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MENUSCode.condition0IsTrue_0.val ) {
{
gdjs.MENUSCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.MENUSCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MENUSCode.GDCREDITSObjects1 */
{for(var i = 0, len = gdjs.MENUSCode.GDCREDITSObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDCREDITSObjects1[i].setColor("238;44;44");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "CREDITS", false);
}}

}


{

gdjs.MENUSCode.GDQUITObjects1.createFrom(runtimeScene.getObjects("QUIT"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDQUITObjects1Objects, runtimeScene, true, true);
}if (gdjs.MENUSCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MENUSCode.GDQUITObjects1 */
{for(var i = 0, len = gdjs.MENUSCode.GDQUITObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDQUITObjects1[i].setColor("7;7;7");
}
}}

}


{

gdjs.MENUSCode.GDQUITObjects1.createFrom(runtimeScene.getObjects("QUIT"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
gdjs.MENUSCode.condition1IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDQUITObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MENUSCode.condition0IsTrue_0.val ) {
{
gdjs.MENUSCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.MENUSCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MENUSCode.GDQUITObjects1 */
{for(var i = 0, len = gdjs.MENUSCode.GDQUITObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDQUITObjects1[i].setColor("247;15;15");
}
}{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.MENUSCode.GDhowtoObjects1.createFrom(runtimeScene.getObjects("howto"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDhowtoObjects1Objects, runtimeScene, true, true);
}if (gdjs.MENUSCode.condition0IsTrue_0.val) {
gdjs.MENUSCode.GDCREDITSObjects1.createFrom(runtimeScene.getObjects("CREDITS"));
{for(var i = 0, len = gdjs.MENUSCode.GDCREDITSObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDCREDITSObjects1[i].setColor("15;15;15");
}
}}

}


{

gdjs.MENUSCode.GDhowtoObjects1.createFrom(runtimeScene.getObjects("howto"));

gdjs.MENUSCode.condition0IsTrue_0.val = false;
gdjs.MENUSCode.condition1IsTrue_0.val = false;
{
gdjs.MENUSCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MENUSCode.mapOfGDgdjs_46MENUSCode_46GDhowtoObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MENUSCode.condition0IsTrue_0.val ) {
{
gdjs.MENUSCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.MENUSCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MENUSCode.GDhowtoObjects1 */
{for(var i = 0, len = gdjs.MENUSCode.GDhowtoObjects1.length ;i < len;++i) {
    gdjs.MENUSCode.GDhowtoObjects1[i].setColor("250;6;6");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "HOWTO", false);
}}

}


}; //End of gdjs.MENUSCode.eventsList0x5b7a18


gdjs.MENUSCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MENUSCode.GDfinalbkObjects1.length = 0;
gdjs.MENUSCode.GDfinalbkObjects2.length = 0;
gdjs.MENUSCode.GDNewObjectObjects1.length = 0;
gdjs.MENUSCode.GDNewObjectObjects2.length = 0;
gdjs.MENUSCode.GDheadingObjects1.length = 0;
gdjs.MENUSCode.GDheadingObjects2.length = 0;
gdjs.MENUSCode.GDSTARTObjects1.length = 0;
gdjs.MENUSCode.GDSTARTObjects2.length = 0;
gdjs.MENUSCode.GDCREDITSObjects1.length = 0;
gdjs.MENUSCode.GDCREDITSObjects2.length = 0;
gdjs.MENUSCode.GDQUITObjects1.length = 0;
gdjs.MENUSCode.GDQUITObjects2.length = 0;
gdjs.MENUSCode.GDhowtoObjects1.length = 0;
gdjs.MENUSCode.GDhowtoObjects2.length = 0;

gdjs.MENUSCode.eventsList0x5b7a18(runtimeScene);
return;

}

gdjs['MENUSCode'] = gdjs.MENUSCode;
